// 时间数据结构定义
const timeData = {
    // 时间段配置
    periods: {
        current: {
            id: 'current',
            name: '当前时间段',
            startDate: '2024-04-01',
            endDate: '2024-04-07',
            type: 'week'  // 可以是 'day', 'week', 'month', 'custom'
        }
        // 可以添加更多时间段
    },
    
    // 分类定义
    categories: {
        first: {
            id: 'first',
            name: '第一类',
            color: '#3498db',
            subcategories: {
                execution: { id: 'execution', name: '执行', color: '#2980b9' },
                intelligence: { id: 'intelligence', name: '情报', color: '#1abc9c' }
            }
        },
        second: {
            id: 'second',
            name: '第二类',
            color: '#2ecc71',
            subcategories: {
                surfing: { id: 'surfing', name: '冲浪', color: '#27ae60' },
                thinking: { id: 'thinking', name: '思考', color: '#16a085' }
            }
        },
        root: {
            id: 'root',
            name: '根源',
            color: '#e74c3c',
            subcategories: {
                manga: { id: 'manga', name: '漫画', color: '#c0392b' },
                anime: { id: 'anime', name: '动画', color: '#e74c3c' }
            }
        },
        entertainment: {
            id: 'entertainment',
            name: '娱乐',
            color: '#f39c12',
            subcategories: {
                games: { id: 'games', name: '游戏', color: '#d35400' },
                manga: { id: 'manga', name: '漫画', color: '#e67e22' },
                anime: { id: 'anime', name: '动画', color: '#f39c12' },
                social: { id: 'social', name: '联系', color: '#f1c40f' },
                novel: { id: 'novel', name: '小说', color: '#e67e22' }
            }
        },
        misc: {
            id: 'misc',
            name: '杂项',
            color: '#9b59b6',
            subcategories: {
                daily: { id: 'daily', name: '日常', color: '#8e44ad' },
                engineering: { id: 'engineering', name: '工程', color: '#9b59b6' }
            }
        }
    },

    // 时间记录
    records: {
        // 按时间段ID组织
        'current': {
            // 每日记录
            '2024-04-01': {
                date: '2024-04-01',
                entries: [
                    {
                        categoryId: 'first',
                        subcategoryId: 'execution',
                        duration: 133, // 分钟
                        details: '毕设2h13m'
                    },
                    // ... 更多记录
                ]
            }
            // ... 更多日期
        }
        // ... 更多时间段
    },

    // 统计数据缓存（可选，用于提高性能）
    stats: {
        'current': {
            totalTime: 5647, // 总时间（分钟）
            categoryTotals: {
                'first': 878,
                'second': 154,
                'root': 978,
                'entertainment': 1687,
                'misc': 1950
            }
            // ... 更多统计数据
        }
    }
};

// 工具函数
const timeUtils = {
    // 时间格式转换：分钟 -> "Xh Ym"
    minutesToTime(minutes) {
        if (!minutes) return '0m';
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
    },

    // 时间格式转换："Xh Ym" -> 分钟
    timeToMinutes(timeStr) {
        if (!timeStr) return 0;
        const hours = (timeStr.match(/(\d+)h/) || [0, 0])[1];
        const minutes = (timeStr.match(/(\d+)m/) || [0, 0])[1];
        return parseInt(hours) * 60 + parseInt(minutes);
    },

    // 获取时间段内的所有日期
    getPeriodDates(period) {
        const dates = [];
        let currentDate = new Date(period.startDate);
        const endDate = new Date(period.endDate);
        
        while (currentDate <= endDate) {
            dates.push(currentDate.toISOString().split('T')[0]);
            currentDate.setDate(currentDate.getDate() + 1);
        }
        
        return dates;
    },

    // 计算时间段统计数据
    calculatePeriodStats(periodId) {
        const period = timeData.periods[periodId];
        const records = timeData.records[periodId];
        
        const stats = {
            totalTime: 0,
            categoryTotals: {},
            subcategoryTotals: {}
        };

        // 初始化类别统计
        Object.keys(timeData.categories).forEach(catId => {
            stats.categoryTotals[catId] = 0;
            Object.keys(timeData.categories[catId].subcategories).forEach(subId => {
                stats.subcategoryTotals[`${catId}-${subId}`] = 0;
            });
        });

        // 统计每个日期的记录
        this.getPeriodDates(period).forEach(date => {
            const dayRecords = records[date]?.entries || [];
            dayRecords.forEach(entry => {
                stats.totalTime += entry.duration;
                stats.categoryTotals[entry.categoryId] += entry.duration;
                stats.subcategoryTotals[`${entry.categoryId}-${entry.subcategoryId}`] += entry.duration;
            });
        });

        return stats;
    }
};

export { timeData, timeUtils }; 