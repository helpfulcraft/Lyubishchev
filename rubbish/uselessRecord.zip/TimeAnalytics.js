import { timeData, timeUtils } from './timeData.js';

class TimeAnalytics {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.currentPeriod = 'current';
        this.initializeUI();
        this.loadData();
    }

    initializeUI() {
        // 创建时间段选择器
        this.createPeriodSelector();
        
        // 创建主要数据展示区域
        this.createDataDisplayArea();
        
        // 初始化图表容器
        this.createChartContainers();
    }

    createPeriodSelector() {
        const selectorContainer = document.createElement('div');
        selectorContainer.className = 'period-selector card';
        
        // 时间段选择
        const periodSelect = document.createElement('select');
        periodSelect.id = 'periodSelect';
        Object.values(timeData.periods).forEach(period => {
            const option = document.createElement('option');
            option.value = period.id;
            option.textContent = `${period.name} (${period.startDate} - ${period.endDate})`;
            periodSelect.appendChild(option);
        });
        
        // 添加新时间段按钮
        const addPeriodBtn = document.createElement('button');
        addPeriodBtn.textContent = '添加时间段';
        addPeriodBtn.onclick = () => this.showAddPeriodDialog();
        
        selectorContainer.appendChild(periodSelect);
        selectorContainer.appendChild(addPeriodBtn);
        this.container.appendChild(selectorContainer);
        
        // 监听时间段变化
        periodSelect.onchange = () => {
            this.currentPeriod = periodSelect.value;
            this.loadData();
        };
    }

    createDataDisplayArea() {
        const displayArea = document.createElement('div');
        displayArea.className = 'data-display';
        
        // 总览卡片
        const overviewCard = document.createElement('div');
        overviewCard.className = 'card overview-card';
        overviewCard.innerHTML = `
            <h2>总览</h2>
            <div class="summary-grid" id="summaryGrid"></div>
        `;
        
        // 详细数据卡片
        const detailsCard = document.createElement('div');
        detailsCard.className = 'card details-card';
        detailsCard.innerHTML = `
            <h2>详细数据</h2>
            <div class="tab-container">
                <div class="tab-buttons">
                    <button class="tab-button active" data-tab="daily">每日分布</button>
                    <button class="tab-button" data-tab="category">类别分布</button>
                    <button class="tab-button" data-tab="subcategory">子类别分布</button>
                </div>
                <div class="tab-content" id="chartArea"></div>
            </div>
        `;
        
        displayArea.appendChild(overviewCard);
        displayArea.appendChild(detailsCard);
        this.container.appendChild(displayArea);
        
        // 设置标签切换事件
        this.setupTabEvents();
    }

    createChartContainers() {
        const chartArea = document.getElementById('chartArea');
        
        // 创建图表容器
        ['daily', 'category', 'subcategory'].forEach(type => {
            const container = document.createElement('div');
            container.id = `${type}Chart`;
            container.className = 'chart-container' + (type === 'daily' ? ' active' : '');
            container.style.height = '400px';
            chartArea.appendChild(container);
        });
    }

    setupTabEvents() {
        const tabButtons = document.querySelectorAll('.tab-button');
        const chartContainers = document.querySelectorAll('.chart-container');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                // 更新按钮状态
                tabButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                // 更新图表显示
                const targetTab = button.dataset.tab;
                chartContainers.forEach(container => {
                    container.classList.remove('active');
                    if (container.id === `${targetTab}Chart`) {
                        container.classList.add('active');
                    }
                });
                
                // 重新渲染当前图表
                this.renderCharts(targetTab);
            });
        });
    }

    loadData() {
        const stats = timeUtils.calculatePeriodStats(this.currentPeriod);
        this.updateSummary(stats);
        this.renderCharts('daily'); // 默认显示每日分布
    }

    updateSummary(stats) {
        const summaryGrid = document.getElementById('summaryGrid');
        summaryGrid.innerHTML = ''; // 清空现有内容
        
        // 添加总计
        const totalItem = document.createElement('div');
        totalItem.className = 'summary-item total';
        totalItem.innerHTML = `
            <h3>总计时间</h3>
            <p>${timeUtils.minutesToTime(stats.totalTime)}</p>
        `;
        summaryGrid.appendChild(totalItem);
        
        // 添加各类别统计
        Object.entries(stats.categoryTotals).forEach(([catId, minutes]) => {
            const category = timeData.categories[catId];
            const item = document.createElement('div');
            item.className = 'summary-item';
            item.innerHTML = `
                <h3>${category.name}</h3>
                <p style="color: ${category.color}">${timeUtils.minutesToTime(minutes)}</p>
            `;
            summaryGrid.appendChild(item);
        });
    }

    renderCharts(type) {
        const stats = timeUtils.calculatePeriodStats(this.currentPeriod);
        const period = timeData.periods[this.currentPeriod];
        
        switch(type) {
            case 'daily':
                this.renderDailyChart(period, stats);
                break;
            case 'category':
                this.renderCategoryChart(stats);
                break;
            case 'subcategory':
                this.renderSubcategoryChart(stats);
                break;
        }
    }

    renderDailyChart(period, stats) {
        const dates = timeUtils.getPeriodDates(period);
        const chartData = {
            labels: dates,
            datasets: Object.entries(timeData.categories).map(([catId, category]) => ({
                label: category.name,
                data: dates.map(date => {
                    const dayRecords = timeData.records[this.currentPeriod][date]?.entries || [];
                    return dayRecords
                        .filter(entry => entry.categoryId === catId)
                        .reduce((sum, entry) => sum + entry.duration, 0);
                }),
                backgroundColor: category.color
            }))
        };

        const ctx = document.getElementById('dailyChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                scales: {
                    x: { stacked: true },
                    y: {
                        stacked: true,
                        ticks: { callback: value => timeUtils.minutesToTime(value) }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => `${context.dataset.label}: ${timeUtils.minutesToTime(context.raw)}`
                        }
                    }
                }
            }
        });
    }

    renderCategoryChart(stats) {
        const chartData = {
            labels: Object.values(timeData.categories).map(cat => cat.name),
            datasets: [{
                data: Object.values(stats.categoryTotals),
                backgroundColor: Object.values(timeData.categories).map(cat => cat.color)
            }]
        };

        const ctx = document.getElementById('categoryChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: chartData,
            options: {
                responsive: true,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => `${context.label}: ${timeUtils.minutesToTime(context.raw)}`
                        }
                    }
                }
            }
        });
    }

    renderSubcategoryChart(stats) {
        const data = [];
        Object.entries(timeData.categories).forEach(([catId, category]) => {
            const categoryData = {
                name: category.name,
                value: stats.categoryTotals[catId],
                itemStyle: { color: category.color },
                children: Object.entries(category.subcategories).map(([subId, sub]) => ({
                    name: sub.name,
                    value: stats.subcategoryTotals[`${catId}-${subId}`],
                    itemStyle: { color: sub.color }
                }))
            };
            data.push(categoryData);
        });

        const chart = echarts.init(document.getElementById('subcategoryChart'));
        chart.setOption({
            series: [{
                type: 'sunburst',
                data: data,
                radius: ['20%', '90%'],
                label: {
                    rotate: 'radial',
                    formatter: params => {
                        return [
                            params.name,
                            timeUtils.minutesToTime(params.value)
                        ].join('\n');
                    }
                }
            }]
        });
    }

    showAddPeriodDialog() {
        const dialog = document.createElement('div');
        dialog.className = 'modal';
        dialog.innerHTML = `
            <div class="modal-content">
                <h3>添加新时间段</h3>
                <form id="addPeriodForm">
                    <div class="form-group">
                        <label>名称：</label>
                        <input type="text" id="periodName" required>
                    </div>
                    <div class="form-group">
                        <label>开始日期：</label>
                        <input type="date" id="startDate" required>
                    </div>
                    <div class="form-group">
                        <label>结束日期：</label>
                        <input type="date" id="endDate" required>
                    </div>
                    <div class="form-group">
                        <label>类型：</label>
                        <select id="periodType">
                            <option value="day">日</option>
                            <option value="week">周</option>
                            <option value="month">月</option>
                            <option value="custom">自定义</option>
                        </select>
                    </div>
                    <div class="button-group">
                        <button type="submit">确定</button>
                        <button type="button" onclick="this.closest('.modal').remove()">取消</button>
                    </div>
                </form>
            </div>
        `;
        
        document.body.appendChild(dialog);
        
        document.getElementById('addPeriodForm').onsubmit = (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const newPeriod = {
                id: Date.now().toString(),
                name: formData.get('periodName'),
                startDate: formData.get('startDate'),
                endDate: formData.get('endDate'),
                type: formData.get('periodType')
            };
            
            // 添加新时间段
            timeData.periods[newPeriod.id] = newPeriod;
            timeData.records[newPeriod.id] = {};
            
            // 更新选择器
            this.createPeriodSelector();
            
            dialog.remove();
        };
    }
}

export default TimeAnalytics; 